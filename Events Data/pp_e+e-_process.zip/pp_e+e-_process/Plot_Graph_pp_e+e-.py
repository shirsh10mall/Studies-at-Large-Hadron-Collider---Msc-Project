import pandas as pd
path = r"/home/shirsh/pp_e+e-_process/data_pp_e+e-.csv"
data = pd.read_csv( path, sep="," )
import matplotlib.pyplot as plt

plt.figure(0)
plt.hist( data['invariant_mass_electron'], bins=100, density=True )
plt.savefig(path+'_'+'invariant_mass_electron', format="pdf")
# plt.show()

plt.figure(1)
plt.hist( data['transverse_momentum_electron_1'], bins=100, density=True )
plt.savefig(path+'_'+'transverse_momentum_electron_1', format="pdf")
#plt.show()

plt.figure(2)
plt.hist( data['transverse_momentum_electron_2'], bins=100, density=True )
plt.savefig(path+'_'+'transverse_momentum_electron_2', format="pdf")
#plt.show()


#for column in data.columns.values:
#	plt.hist( data[column], bins=100, density=True )
#	plt.savefig('fig_'+column, format="pdf")
#	plt.show()


#import plotly.express as px
#fig = px.histogram( data, x='transverse_momentum_electron_1' )
#fig.write_image('./fig.pdf') # $ pip install -U kaleido
#fig.show()
