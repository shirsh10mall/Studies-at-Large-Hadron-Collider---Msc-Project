import pandas as pd
path = r"/home/shirsh/pp_e+e-_process/data_pp_e+e-.csv"
data = pd.read_csv( path, sep="," )
import plotly.express as px


for column in data.columns.values:
	fig = px.histogram( data, x=column )
	fig.write_image(column+'_fig.pdf') # $ pip install -U kaleido
	# fig.show()
