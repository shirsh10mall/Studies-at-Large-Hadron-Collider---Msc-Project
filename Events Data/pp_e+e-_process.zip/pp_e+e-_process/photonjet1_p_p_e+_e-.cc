//
//  ttbar.cpp
//  
//
//  Created by Abhishek Iyer on 21/04/2015.
//
//

#include "Pythia8/Pythia.h"
#include "Pythia8Plugins/HepMC2.h"

//#include "Pythia8/Pythia.h"
//#ifndef HEPMC2
//#include "Pythia8Plugins/HepMC3.h"
//#else
//#include "Pythia8Plugins/HepMC2.h"
//#endif


using namespace Pythia8;

int main()

{
    //interface for conversion from pythia 8 event to hepmc event
    
      Pythia8::Pythia8ToHepMC topHepMC("pp_e+e-.hepmc");
    
    //specify file where hepmc evnts will be stored
   // HepMC::IO_GenEvent ascii_io("/Volumes/NONAME/abhishek_files/spin2-gg-diphoton.hepmc", std::ios::out);
//   HepMC::IO_GenEvent ascii_io("my_first_file.hepmc", std::ios::out);
//    HepMC::IO_GenEvent ascii_io("/Volumes/Untitled/zpe10broad.hepmc", std::ios::out);
// HepMC::IO_GenEvent ascii_io("w2.hepmc", std::ios::out);

    
    //Generator
    // Generator. Shorthand for the event.
    Pythia pythia;
    Event& event = pythia.event;
    
    // Read in commands from external file.
    pythia.readFile("example_pp_e+e-.cmnd");
    
    //pythia.readString("Next:numberShowEvent = 20");
//   pythia.readString("9000007:onMode=off");
//	pythia.readString("9000007:onIfAny=22");

    // Extract settings to be used in the main program.
  //  int nEvent   = pythia.mode("Main:numberOfEvents");
  //  int nAbort   = pythia.mode("Main:timesAllowErrors");
   // double eCM   = pythia.parm("Beams:eCM");
    //  double tbeta = pythia.parm()
    // Initialize.
    pythia.init();
   // Hist mult("charged multiplicity", 100, -0.5, 799.5);
    

    
    int p=0;

    { 
// cout<<iEvent<<"\n";
        
         // Begin event loop. Generate event. Skip if error.
  for (int iEvent = 0; iEvent < 10000; ++iEvent) {
    if (!pythia.next()) continue;

    // Find number of all final charged particles and fill histogram.
    int nCharged = 0;
    for (int i = 0; i < pythia.event.size(); ++i)
      if (pythia.event[i].isFinal() && pythia.event[i].isCharged())
        ++nCharged;
  //  mult.fill( nCharged );

    // Construct new empty HepMC event, fill it and write it out.
    topHepMC.writeNextEvent( pythia );
}

  // End of event loop. Statistics. Histogram.        
        
        
        
        //Write the HepMC event to file.
     
        
      pythia.stat();
   //   cout << mult;

        
    //Event loop  ends

//    cout<<p<<"\n";
    return 0;

}}
