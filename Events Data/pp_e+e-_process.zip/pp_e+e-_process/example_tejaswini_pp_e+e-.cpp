//
//  code_iyer_new.cpp
//  
//
//  Created by Abhishek Iyer on 05/09/2015.
//
//

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <utility>
#include <vector>
#include <math.h>

#include <TFile.h>

#include "TROOT.h"
#include "TSystem.h"
#include "TApplication.h"

#include "TString.h"

#include "TH2.h"
#include "THStack.h"
#include "TLegend.h"
#include "TPaveText.h"
#include "TClonesArray.h"
#include "TLorentzVector.h"

#include "TCanvas.h"

#include "modules/Delphes.h"
#include "classes/DelphesClasses.h"
#include "classes/DelphesFactory.h"

#include "ExRootAnalysis/ExRootTreeReader.h"
#include "ExRootAnalysis/ExRootTreeWriter.h"
#include "ExRootAnalysis/ExRootTreeBranch.h"
#include "ExRootAnalysis/ExRootResult.h"
#include "ExRootAnalysis/ExRootUtilities.h"

#include "fastjet/PseudoJet.hh"
#include "fastjet/JetDefinition.hh"
#include "fastjet/ClusterSequence.hh"
#include "fastjet/ClusterSequenceArea.hh"
#include "fastjet/contrib/Nsubjettiness.hh"
#include "fastjet/contrib/Njettiness.hh"
#include "fastjet/contrib/NjettinessPlugin.hh"
//#include "fastjet/contrib/WinnerTakeAllRecombiner.hh"

#include <fastjet/Selector.hh>
#include "fastjet/tools/Filter.hh"
#include "fastjet/tools/Pruner.hh"
#include "fastjet/tools/MassDropTagger.hh"

#include "fastjet/contrib/Nsubjettiness.hh"
#include "fastjet/contrib/Njettiness.hh"
#include "fastjet/contrib/NjettinessPlugin.hh"
//#include "fastjet/contrib/WinnerTakeAllRecombiner.hh"

#include <sstream>
#include "fastjet/contrib/EnergyCorrelator.hh"

using namespace std;
using namespace fastjet;
using namespace fastjet::contrib;

#include "/home/shirsh/softwares/Delphes-3.5.0/HEPTopTagger2/HEPTopTagger.hh"
/// #include "/home/shirsh/softwares/Delphes-3.5.0/HEPTopTagger2/HEPTopTagger.cc"
#include <fastjet/tools/JHTopTagger.hh>

//.................................................................................
//......... Random number generator .......

#include <chrono>

/* double rangen()
{
    std::mt19937_64 rng;
    // initialize the random number generator with time-dependent seed
    uint64_t timeSeed = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    std::seed_seq ss{uint32_t(timeSeed & 0xffffffff), uint32_t(timeSeed>>32)};
    rng.seed(ss);
    // initialize a uniform distribution between 0 and 1
    std::uniform_real_distribution<double> unif(0, 1);
    // ready to generate random numbers
     const int nSimulations = 1;
     double currentRandomNumber;
    for (int i = 0; i < nSimulations; i++)
    {
        currentRandomNumber = unif(rng);
   //     std::cout << currentRandomNumber << std::endl;
    }
   // return 0;
     return currentRandomNumber;
}
*///.................................................................................


int main()
{     vector<PseudoJet> inputList, inputList1, inputList3;
      vector<PseudoJet> outputList,outputList1,outputList3;
      PseudoJet jetphoton,jethadron,jettrack; //track, emcal, hcal pseudojets which is pushed into inputlist
      PseudoJet jetparticle,jettowerEM,jettowerHAD; //track, emcal, hcal pseudojets which is pushed into inputlist
 //   TFile file1("/Volumes/Abhishek/root/photonjet/14TeV/zpmu14_3.root","READ");//Fulvio Antoni
 //   TFile file1("/Volumes/Abhishek/root/photonjet/14TeV/zpe14HL_10.root","READ");//100 TeV
 //   TFile file1("/Volumes/Untitled/zpmu14_7.root","READ");// HL
 //   TFile file1("/Volumes/Untitled/100TeV/zpe100_50.root","READ");
    
   /// TFile file1("/Users/abhishekiyer/Desktop/codes/pythia8243/examples/zpmu4.root","READ");
   ///    TFile file1("/home/shirsh/softwares/Delphes-3.5.0/my_first_file_delphes_output_CMS.root","READ");
  ///  TFile file1("/home/shirsh/softwares/Delphes-3.5.0/delphes_output.root","READ");
    TFile file1("/home/shirsh/pp_e+e-_process/pp_e+e-_CMS.root","READ");
    //   TFile file1("/Volumes/Abhishek/root/photonjet/narrowe100_50.root","READ");
//    TFile file1("/Volumes/Abhishek/root/cont_3000_11Novb.root","READ");
    gSystem->Load("libDelphes");
    
    
    // Create chain of root trees
    TChain chain("Delphes");
//    chain.Add("/Volumes/Abhishek/root/photonjet/14TeV/zpmu14_3.root");
  //  chain.Add("/Volumes/Abhishek/root/photonjet/narrowe100_50.root");
//chain.Add("/Volumes/Abhishek/root/contpT.root");
//  chain.Add("/Volumes/Abhishek/root/photonjet/14TeV/zpe14HL_10.root");//100 TeV
 //  chain.Add("/Volumes/Untitled/zpmu14_7.root");//HL
// chain.Add("/Volumes/Untitled/100TeV/zpe100_50.root");
  ///  chain.Add("/Users/abhishekiyer/Desktop/codes/pythia8243/examples/zpmu4.root");
  /// chain.Add("/home/shirsh/softwares/Delphes-3.5.0/my_first_file_delphes_output_CMS.root");
  /// chain.Add("/home/shirsh/softwares/Delphes-3.5.0/delphes_output.root");
  chain.Add("/home/shirsh/pp_e+e-_process/pp_e+e-_CMS.root");
    //Create object of class ExRottTreeReader
    ExRootTreeReader *treeReader = new ExRootTreeReader(&chain);
    Long64_t numberOfEntries = treeReader->GetEntries();
//    TClonesArray *branchphoton = treeReader->UseBranch("photonisolation");//ECAL output
    TClonesArray *branchelectron = treeReader->UseBranch("Electron");//ECAL output
    TClonesArray *branchmuon = treeReader->UseBranch("Muon");//ECAL output
    
    TClonesArray *branchtower = treeReader->UseBranch("Tower");
    TClonesArray *branchtrack = treeReader->UseBranch("Track");
    TClonesArray *particle = treeReader->UseBranch("Particle");
    TClonesArray *branchjets = treeReader->UseBranch("Jet");
    TClonesArray *branchMissingET = treeReader->UseBranch("MissingET");


   // TClonesArray *branchEFlowTrack = treeReader->UseBranch("EFlowTrack");
   // TClonesArray *branchEFlowTower = treeReader->UseBranch("EFlowPhoton");
   // TClonesArray *branchEFlowNhadron = treeReader->UseBranch("EFlowHadron");

   // TFile* fileout=new TFile("diphotonout_CA.root","recreate");
    TFile* fileout=new TFile("pp_e+e-_CMS_out.root","recreate");
    
    
    TTree *tree = new TTree("TreeB","Signal");
    
    //jet and event variables variables
    
    Float_t tau1=0;    
    Float_t higgspt=0;
    Float_t top1pt=0;
    Float_t top2pt=0;
    Float_t gluonpt=0;
    Float_t mass=0;
    Float_t edge=0;
    Float_t edge1=0;
    Float_t missingET=0;
    Float_t edge_tprime=0;
    Float_t edge_hprime=0;
    Float_t transversemass_hprime =0;
    Float_t transversemass_tprime=0;
    Float_t transversemass_tprime_real_max=0;
    Float_t transversemass_tprime_real_min=0;
    Float_t invmassmax=0;
    Float_t invmassmin=0;
    Float_t invmass1=0;
    Float_t phileading=0;

    Float_t invmass2=0;

    Float_t invmass3=0;

    Float_t invmasstot=0;
    Float_t thetaJ0=0;
    Float_t thetaJ1=0;
    Float_t thetaJ2=0;
    Float_t edge_real=0;
    Float_t edge_real1=0;
    Float_t min_invmass=0;

    Float_t mass_total=0;
    Float_t edge_real_hprime=0;
    
    Float_t tprimept=0;
    
    Float_t tau21_beta1=1;
    Float_t tau31_beta1=1;
    Float_t tau32_beta1=1;
    
    //subleading jet subjettiness
    Float_t tau1s=0;
    Float_t tau21_beta1s=1;
    Float_t tau31_beta1s=1;
    Float_t tau32_beta1s=1;
    
    
    Float_t Area=0;
    Float_t thetaJ=0;
    Float_t trackno=0;
    Float_t LambdaJ=0;
    Float_t rho=0;
    Float_t epsJ=0;
    Float_t pionpT=0;
    
    Float_t pTbyM=0;
    Float_t Rdelgamgam=100;
    Float_t Rdelphoton=0;


    Float_t ecf0=0;
    Float_t ecf1=0;
    Float_t ecf2=0;
    Float_t ecf3=0;
    Float_t ecf4=0;
    Float_t ecf5=0;
    
    Float_t ecfr0=1;
    Float_t ecfr1=1;
    Float_t ecfr2=1;
    Float_t ecfr3=1;
    Float_t ecfr4=1;
    
    
    Float_t ecfdr1=1;
    Float_t ecfdr2=1;
    Float_t ecfdr3=1;
    Float_t ecfdr4=1;
    Float_t jetno=0;
    Float_t jetno1=0;
    Float_t  pt3=0;
    Float_t  pt3a=0;
    
    Float_t deltaR1=0;
    Float_t deltaR2=0;
    Float_t deltaR3=0;
    

    //photon variables
    Float_t diphotonmin=0;
    Float_t photonnumber=0;
    Float_t photonnumber1=0;
    Float_t photonpT0=0;
    Float_t photonpT1=0;
    Float_t photonpT2=0;
    Float_t mass1=0;
    Float_t mass2=0;
    Float_t mass3=0;
    Float_t bjet=0;
    Float_t bmeson=0;
    
    Float_t etaphoton1=0;
    Float_t etaphoton2=0;
    Float_t deltaeta1=0;
    Float_t deltaeta2=0;

    Float_t jetm1=0;
    Float_t jetm2=0;
    Float_t deltaetasubjet=0;
    Float_t ptsubjetplot=0;
    Float_t costheta=0;
    Float_t leadingjet=0;
    Float_t jet_number =0;
    Float_t higgsjet=0;
    
    Float_t diphotonminsubjet=0;

    
    ofstream variables7;
  ///  variables7.open("/Users/abhishekiyer/Dropbox/chargedvsneutral/HLfiles/zpmu14_4.txt",  std::ios::app);
    variables7.open("/home/shirsh/pp_e+e-_process/pp_e+e-_CMS_out.txt",  std::ios::app);

    
    cout<<numberOfEntries<<"\n";
    TLorentzVector momentum;
    TObject *object;
    Track *track;
    Tower *tower;
    GenParticle *particle1;
    int count1=0;
    int count2=0;
    int count3=0;
    int count4=0;
    int count=0;
    int count4a=0;
    int eventcount=0;
    int eventcount1=0;
    
    
    /// To Collect and Expport some data in csv form
    fstream fout;
    fout.open("data_pp_e+e-.csv", ios::out | ios::app); ///
    /// Adding Columns to data.csv
          fout << "invariant_mass_electron" << ","
		<< "px1" << ","
		<< "py1" << ","
		<< "ptl1" << ","
		<< "px2" << ","
		<< "py2" << ","
		<< "ptl2" << ","
		<< "etal1" << ","
		<< "etal2" << "\n";
    ///
    
    for(Int_t entry=0; entry < numberOfEntries; ++entry)
    { treeReader->ReadEntry(entry);

        Float_t pxtot=0;
        Float_t pytot=0;        
        
        double ptvector [100];
        double phivector[100];
        double etavector[100];
        
        Float_t pxelectron=0;
        Float_t pyelectron=0;
        Float_t pzelectron=0;
        Float_t Eelectron=0;
        Float_t Ptelectron=0;
        
        Float_t pxmuon=0;
        Float_t pymuon=0;
        Float_t pzmuon=0;
        Float_t Emuon=0;
        Float_t Ptmuon=0;
        
        Float_t pnx=0;
        Float_t pny=0;
        Float_t pnz=0;
        Float_t pne=0;
        
        Float_t pxtop2=0;
        Float_t pytop2=0;
        Float_t pztop2=0;
        Float_t Etop2=0;
        Float_t etatop2=0;
        
        Float_t pxtop1=0;
        Float_t pytop1=0;
        Float_t pztop1=0;
        Float_t Etop1=0;
        
        Float_t pxgluon=0;
        Float_t pygluon=0;
        Float_t pzgluon=0;
        Float_t Egluon=0;
        Float_t zprimemass=0;
        
        int k=0;
        Float_t pxtau[20]={};
        Float_t pytau[20]={} ;
        Float_t pztau[20]={};
        Float_t energytau[20]={};
        Float_t etatau[20]={};
        Float_t phitau[20]={};
        Float_t pttau[20]={};
        int counttaujet=0;

        
        double R = 0.4;
            JetDefinition jet_def1(antikt_algorithm, R);
            //non area clustering
            ClusterSequence sequence1(inputList,jet_def1);
            
            outputList.clear();
            outputList1.clear();
            
            outputList = sorted_by_pt(sequence1.inclusive_jets(80.0));
  	    inputList.clear();
 

        Float_t ptl1=0;
        Float_t ptl2=0;
        Float_t phil1=0;
        Float_t phil2=0;
        Float_t etal1=0;
        Float_t etal2=0;
        Float_t missET=0;
     //   cout<<branchmuon->GetEntriesFast()<<"\n";

      //  if (branchmuon->GetEntriesFast()==2)
      if (branchelectron->GetEntriesFast()==2)
        {

        /*    Muon *muon1;
            Muon *muon2;
            MissingET *missing;
            cout<<entry<<"\t"<<missing->MET<<"\n";
            muon1 = (Muon *) branchmuon->At(0);
            muon2 = (Muon *) branchmuon->At(1);
            ptl1=muon1->PT;
            ptl2=muon2->PT;
            etal1 = muon1->Eta;
            etal2= muon2->Eta;
            phil1 = muon1->Phi;
            phil2=muon2->Phi; 
       */
 

            Electron *muon1;
            Electron *muon2;
            muon1 = (Electron *) branchelectron->At(0);
            muon2 = (Electron *) branchelectron->At(1);
            ptl1=muon1->PT;
            ptl2=muon2->PT;
            etal1 = muon1->Eta;
            etal2= muon2->Eta;
            phil1 = muon1->Phi;
            phil2 = muon2->Phi;
            
            
            Float_t invmassd=0;
            for (unsigned int jj=0; jj<particle -> GetEntriesFast(); ++jj)
            {  //2
                GenParticle *genparticle=(GenParticle*) particle->At(jj);

                if ((genparticle->PID==22||genparticle->PID==23)&&genparticle->Status==22)
                { // cout<<entry<<"\t"<<"hi"<<"\n";
                    
                    Float_t  pxd1=genparticle->Px;
                    
                    
                    Float_t  pyd1=genparticle->Py;
                    
                    Float_t   pzd1=genparticle->Pz;
                    
                    Float_t  ped1=genparticle->E;
                    
                    Float_t Einvd=ped1;
                    Float_t pxinvd=pxd1;
                    Float_t pyinvd=pyd1;
                    Float_t pzinvd=pzd1;
                    invmassd=sqrt(pow(Einvd,2)-pow(pxinvd,2)-pow(pyinvd,2)-pow(pzinvd,2));
                }
            }//2

            
            Float_t delphi= phil1-phil2;
            if (abs(delphi)<=pi)
            {
                delphi= abs(phil1-phil2);
            } else
            {
                delphi=2*pi-abs(delphi);
            }
            
          Float_t  E1=ptl1*cosh(etal1);
          Float_t  pz1=ptl1*sinh(etal1);
          Float_t  px1=ptl1*cos(phil1);
          Float_t  py1=ptl1*sin(phil1);
            
          Float_t  E2=ptl2*cosh(etal2);
          Float_t  pz2=ptl2*sinh(etal2);
          Float_t  px2=ptl2*cos(phil2);
          Float_t  py2=ptl2*sin(phil2);
          Float_t Einv=E1+E2;
          Float_t pxinv=px1+px2;
          Float_t pyinv=py1+py2;
          Float_t pzinv=pz1+pz2;
          Float_t invmassmu=sqrt(pow(Einv,2)-pow(pxinv,2)-pow(pyinv,2)-pow(pzinv,2));
       ///   cout<<invmassmu<</*"\t"<<ptl1<<"\t"<<ptl2<<*/"\n"; ///
          
          
          /// Adding Data to data.csv file
          fout << invmassmu << ","
          	<< px1 << ","
		<< py1 << ","
		<< ptl1 << ","
		<< px2 << ","
		<< py2 << ","
		<< ptl2 << ","
		<< etal1 << ","
		<< etal2 << "\n";
          
          ///
          
 //           if (ptl1>500)
 //           {
               
                variables7<<setprecision(3)<<"\t"<<invmassmu<<"\t"<<invmassd<<"\n";
        
                eventcount=eventcount+1;
 //           }
        }
    //    cout<<"------------------------------------------------------------------"<<"\n";

    }//event loop

   // cout<<"Number of di-`muon' events"<<"\t"<<eventcount<<"\n";
    cout<<"Number of di-`electron' events"<<"\t"<<eventcount<<"\n";

    tree->Write();
    delete fileout;
    variables7.close();
    return 0;

}//main prog
